#!/bin/bash
cd /home/z/my-project/vscode-sast/final/vscode-extension
npx @vscode/vsce package --out ./